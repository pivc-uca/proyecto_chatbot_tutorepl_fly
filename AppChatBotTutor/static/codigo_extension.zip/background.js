// Capa de abstracción para compatibilidad (Chrome/Firefox/Edge)
const runtime = (typeof browser !== 'undefined') ? browser.runtime : chrome.runtime;

// Variables globales para almacenar temporalmente los últimos eventos
let lastErrorMessage = null;
let lastListEvent = null;

// 1. Manejador de instalación 
runtime.onInstalled.addListener(() => {
    console.log("Error Monitor Extension Installed");
});

// 2. ESCUCHAR mensajes internos (desde content.js)
runtime.onMessage.addListener((request, sender, sendResponse) => {

    // --- ERROR EPL ---
    if (request.action === 'errorCaptured' && request.payload) {
        lastErrorMessage = request.payload;
        console.log("Background: Error recibido y almacenado:", lastErrorMessage);
    }

    // --- LISTA VACÍA ---
    if (request.action === 'emptyListDetected' && request.payload) {
        lastListEvent = "LIST_EMPTY:" + request.payload;
        console.log("Background: Lista vacía detectada:", lastListEvent);
    }

    // --- LISTA LLENA ---
    if (request.action === 'listFilledDetected' && request.payload) {
        lastListEvent = "LIST_FILLED:" + request.payload;
        console.log("Background: Lista llena detectada:", lastListEvent);
    }
});

// 3. ESCUCHAR peticiones externas (desde Flask)
runtime.onMessageExternal.addListener((request, sender, sendResponse) => {
	
	// --- RESPUESTA A LA VERIFICACIÓN DE EXTENSIÓN ---
    if (request.message === "version") {
        sendResponse({
            version: runtime.getManifest().version,
            name: runtime.getManifest().name
        });
        return true;
    }

    // --- PETICIÓN DE ERRORES ---
    if (request.action === 'requestError') {

        // Prioridad: error > eventos de lista
        if (lastErrorMessage) {
            sendResponse({ error: lastErrorMessage });
            console.log("Background: Enviando error a Flask.");
            lastErrorMessage = null;
            return true;
        }

        if (lastListEvent) {
            sendResponse({ error: lastListEvent });
            console.log("Background: Enviando evento de lista a Flask.");
            lastListEvent = null;
            return true;
        }

        // Si no hay nada que enviar
        sendResponse({ error: null });
        return true;
    }
});

