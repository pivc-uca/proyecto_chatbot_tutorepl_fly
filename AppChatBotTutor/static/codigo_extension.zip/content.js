// Capa de abstracción para compatibilidad (Chrome/Firefox/Edge)
const runtime = (typeof browser !== 'undefined') ? browser.runtime : chrome.runtime;

// Bandera para evitar enviar el mismo mensaje múltiples veces en un solo ciclo de aparición/desaparición
let isErrorBeingProcessed = false;
let isListEmptyBeingProcessed = false;
let isListFilledBeingProcessed = false;

// Función que contiene la lógica de detección y envío
function checkForAndSendError() {
    // 1. Buscamos el popup
    const errorNode = document.querySelector('#dialog-validation');

    // 2. Comprobamos si existe Y está visible (generalmente tiene display:block o no tiene display:none)
    // También usamos un simple chequeo de estilo para verificar si está oculto/visible
    const isVisible = errorNode && errorNode.offsetWidth > 0 && errorNode.offsetHeight > 0;

    if (isVisible && !isErrorBeingProcessed) {
        // El popup está visible y no lo hemos procesado en este ciclo
        isErrorBeingProcessed = true; // Bloquea el procesamiento
        
        const errorMessage = errorNode.textContent.trim();
        console.log('Mensaje de error capturado:', errorMessage);

        // ENVIAR el mensaje al background script (service worker)
        runtime.sendMessage({
            action: 'errorCaptured',
            payload: errorMessage
        });

        // 3. Establecer un temporizador para "desbloquear" el procesamiento
        // Esto asume que el usuario verá y cerrará el error en 2-3 segundos.
        // Después de este tiempo, la bandera se resetea para esperar el próximo error.
        setTimeout(() => {
            isErrorBeingProcessed = false;
            console.log("Procesamiento de error desbloqueado. Listo para el próximo mensaje.");
        }, 6000); // Se desbloquea en 6 segundos
    }
	
    // --- DETECCIÓN DE LISTA OUTPUT ---
    const listNode = document.querySelector('.output_scrolling .outputlist');

    if (listNode) {
        const items = listNode.querySelectorAll('li');
        const isEmpty = items.length === 0;

        // --- LISTA VACÍA ---
        if (isEmpty && !isListEmptyBeingProcessed) {
            isListEmptyBeingProcessed = true;
            isListFilledBeingProcessed = false; // reset del estado contrario

            console.log("La lista está vacía. Enviando notificación...");

            runtime.sendMessage({
                action: 'emptyListDetected',
                payload: 'La lista outputlist está vacía'
            });

            setTimeout(() => {
                isListEmptyBeingProcessed = false;
                console.log("Procesamiento de lista vacía desbloqueado.");
            }, 6000);
        }

        // --- LISTA CON ELEMENTOS ---
        if (!isEmpty && !isListFilledBeingProcessed) {
            isListFilledBeingProcessed = true;
            isListEmptyBeingProcessed = false; // reset del estado contrario

            console.log("La lista ahora tiene elementos. Enviando notificación...");
			
			// ENVIAR el mensaje al background script (service worker)
            runtime.sendMessage({
                action: 'listFilledDetected',
                payload: `La lista tiene ${items.length} elementos`
            });

            setTimeout(() => {
                isListFilledBeingProcessed = false;
                console.log("Procesamiento de lista llena desbloqueado.");
            }, 6000);
        }
    }
}

// Monitor de cambios en el DOM
const observer = new MutationObserver((mutations) => {
    // No iteramos en mutations, solo verificamos si ha habido algún cambio
    // que afecte el subárbol o atributos
    checkForAndSendError();
});

// La clave es observar el cuerpo entero con el flag 'subtree' y 'attributes'
observer.observe(document.body, { 
    childList: true, // Para cuando se añade/elimina el nodo padre
    subtree: true,   // Para cuando el popup está anidado y cambia
    attributes: true // Para cuando cambia el estilo (display:none -> display:block)
});